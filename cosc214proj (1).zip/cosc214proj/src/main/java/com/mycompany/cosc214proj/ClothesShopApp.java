/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cosc214proj;

/**
 *
 * @author nycit
 */
import java.util.*;

public class ClothesShopApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ClothesShop shop = new ClothesShop();
        int ID = 0;
        
        for (int i = 0; i < 10000; i++) {
            shop.insertProduct(new Product("Shirt " + ID, 30.0, 1));
            ID++;
        }
        while (true) {
            System.out.println("Welcome to the Clothes Shop!");
            System.out.println("Are you an owner, a customer, or do you want to exit?");
            System.out.println("Press 1 for OWNER");
            System.out.println("Press 2 for CUSTOMER");
            System.out.println("Press 3 to EXIT");

            if (scanner.hasNextInt()) {
                int userType = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character after reading the integer

                switch (userType) {
                    case 1:
                        // Owner mode
                        System.out.println("OWNER");
                        ownerMode(scanner, shop);
                        break;

                    case 2:
                        // Customer mode
                        System.out.println("CUSTOMER");
                        customerMode(scanner, shop);
                        break;

                    case 3:
                        // Exit the program
                        System.out.println("Exiting the Clothes Shop. Goodbye!");
                        scanner.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid option. Please choose a valid option.");
                        break;
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option.");
                scanner.next(); // Consume the invalid input
            }
        }
    }

    private static void ownerMode(Scanner scanner, ClothesShop shop) {
        while (true) {
            System.out.println("\nOWNER OPTIONS:");
            System.out.println("1. Add new product");
            System.out.println("2. Delete product");
            System.out.println("3. Modify product price");
            System.out.println("4. Modify product quantity");
            System.out.println("5. Display products (sorted by price low to high)");
            System.out.println("6. Display products (sorted by price high to low)");
            System.out.println("7. Display products (sorted by quantity low to high)");
            System.out.println("8. Display products (sorted by quantity high to low)");
            System.out.println("9. Exit");

            if (scanner.hasNextInt()) {
                int ownerOption = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character after reading the integer

                switch (ownerOption) {
                    case 1:
                        // Add new product
                        addNewProduct(scanner, shop);
                        break;

                    case 2:
                        // Delete product
                        deleteProduct(scanner, shop);
                        break;

                    case 3:
                        // Modify product price
                        modifyProductPrice(scanner, shop);
                        break;

                    case 4:
                        // Modify product quantity
                        modifyProductQuantity(scanner, shop);
                        break;

                    case 5:
                        // Display products sorted by price low to high
                        System.out.println("\nProducts sorted by price low to high:");
                        shop.displayProducts(Comparator.comparingDouble(Product::getPrice));
                        break;

                    case 6:
                        // Display products sorted by price high to low
                        System.out.println("\nProducts sorted by price high to low:");
                        shop.displayProducts(Comparator.comparingDouble(Product::getPrice).reversed());
                        break;

                    case 7:
                        // Display products sorted by quantity low to high
                        System.out.println("\nProducts sorted by quantity low to high:");
                        shop.displayProducts(Comparator.comparingInt(Product::getQuantity));
                        break;

                    case 8:
                        // Display products sorted by quantity high to low
                        System.out.println("\nProducts sorted by quantity high to low:");
                        shop.displayProducts(Comparator.comparingInt(Product::getQuantity).reversed());
                        break;

                    case 9:
                        // Exit owner mode
                        System.out.println("Exiting owner mode.");
                        return;

                    default:
                        System.out.println("Invalid option. Please choose a valid option.");
                        break;
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option.");
                scanner.next(); // Consume the invalid input
            }
        }
    }

    private static void customerMode(Scanner scanner, ClothesShop shop) {
        while (true) {
            System.out.println("\nCUSTOMER OPTIONS:");
            System.out.println("1. Display products (sorted by price low to high)");
            System.out.println("2. Display products (sorted by price high to low)");
            System.out.println("3. Display products (sorted by quantity low to high)");
            System.out.println("4. Display products (sorted by quantity high to low)");
            System.out.println("5. Search and purchase");
            System.out.println("6. Exit");

            if (scanner.hasNextInt()) {
                int customerOption = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character after reading the integer

                switch (customerOption) {
                    case 1:
                        // Display products sorted by price low to high
                        System.out.println("\nProducts sorted by price low to high:");
                        shop.displayProducts(Comparator.comparingDouble(Product::getPrice));
                        break;

                    case 2:
                        // Display products sorted by price high to low
                        System.out.println("\nProducts sorted by price high to low:");
                        shop.displayProducts(Comparator.comparingDouble(Product::getPrice).reversed());
                        break;

                    case 3:
                        // Display products sorted by quantity low to high
                        System.out.println("\nProducts sorted by quantity low to high:");
                        shop.displayProducts(Comparator.comparingInt(Product::getQuantity));
                        break;

                    case 4:
                        // Display products sorted by quantity high to low
                        System.out.println("\nProducts sorted by quantity high to low:");
                        shop.displayProducts(Comparator.comparingInt(Product::getQuantity).reversed());
                        break;

                    case 5:
                        // Search and purchase
                        searchAndPurchase(scanner, shop);
                        break;

                    case 6:
                        // Exit customer mode
                        System.out.println("Exiting customer mode.");
                        return;

                    default:
                        System.out.println("Invalid option. Please choose a valid option.");
                        break;
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option.");
                scanner.next(); // Consume the invalid input
            }
        }
    }

    private static void addNewProduct(Scanner scanner, ClothesShop shop) {
        System.out.print("Enter product name: ");
        String newProductName = scanner.nextLine();
        System.out.print("Enter product price: $");
        double newProductPrice = scanner.nextDouble();
        System.out.print("Enter product quantity: ");
        int newProductQuantity = scanner.nextInt();
        shop.addNewProduct(newProductName, newProductPrice, newProductQuantity);
    }

    private static void deleteProduct(Scanner scanner, ClothesShop shop) {
        System.out.print("Enter product name to delete: ");
        scanner.nextLine(); // Consume the newline character before reading the string
        String productToDelete = scanner.nextLine();
        shop.deleteProduct(productToDelete);
    }

    private static void modifyProductPrice(Scanner scanner, ClothesShop shop) {
        System.out.print("Enter product name to modify price: ");
        scanner.nextLine(); // Consume the newline character before reading the string
        String productToModifyPrice = scanner.nextLine();
        System.out.print("Enter new product price: $");
        double newPrice = scanner.nextDouble();
        shop.modifyProductPrice(productToModifyPrice, newPrice);
    }

    private static void modifyProductQuantity(Scanner scanner, ClothesShop shop) {
        System.out.print("Enter product name to modify quantity: ");
        scanner.nextLine(); // Consume the newline character before reading the string
        String productToModifyQuantity = scanner.nextLine();
        System.out.print("Enter new product quantity: ");
        int newQuantity = scanner.nextInt();
        shop.modifyProductQuantity(productToModifyQuantity, newQuantity);
    }

    private static void searchAndPurchase(Scanner scanner, ClothesShop shop) {
        System.out.print("Enter the product name to search (or type 'exit' to go back): ");
        String searchProductName = scanner.next();

        if (searchProductName.equalsIgnoreCase("exit")) {
            return; // Exit to customer options
        }

        Product searchedProduct = shop.searchProduct(searchProductName);
        if (searchedProduct != null) {
            System.out.print("Found " + searchProductName + " - Price: $" + searchedProduct.price + " - ");
            if (searchedProduct.quantity > 0) {
                System.out.println("Quantity: " + searchedProduct.quantity);
            } else {
                System.out.println("OUT OF STOCK");
            }

            if (searchedProduct.quantity > 0) {
                System.out.print("Enter the quantity to purchase: ");
                int purchaseQuantity = scanner.nextInt();

                shop.purchaseProduct(searchProductName, purchaseQuantity);

                // Display updated products after purchase
                System.out.println("Updated products after purchase:");
                shop.displayProducts(Comparator.comparingDouble(Product::getPrice));
            }
        } else {
            System.out.println(searchProductName + " not found in the store. Try again.");
        }
    }
}
