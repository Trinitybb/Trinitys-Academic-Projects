/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cosc214proj;

/**
 *
 * @author nycit
 */
import java.util.*;

// Shop class to manage the store's activities
public class ClothesShop {
    private Map<Integer, Product> productMap;  // Using HashMap with ID as key for efficient product storage
    private Set<Product> productSet;            // Using HashSet for efficient product searching

    public ClothesShop() {
        this.productMap = new HashMap<>();
        this.productSet = new HashSet<>();
    }

    // Method to insert a new product into the shop
    public void insertProduct(Product product) {
        productMap.put(product.getId(), product);
        productSet.add(product);
    }

    // Method to remove a product from the shop after selling
    public void removeProduct(Product product) {
        productMap.remove(product.getId());
        productSet.remove(product);
    }

    // Method to display products based on different sorting criteria
    public void displayProducts(Comparator<Product> comparator) {
        List<Product> productList = new ArrayList<>(productSet);
        Collections.sort(productList, comparator);
        for (Product product : productList) {
            System.out.print(product.name + " - Price: $" + product.price + " - ");
            if (product.quantity > 0) {
                System.out.println("Quantity: " + product.quantity);
            } else {
                System.out.println("OUT OF STOCK");
            }
        }
    }

    // Method to search for a product by name (case-insensitive)
    public Product searchProduct(String productName) {
        return productMap.get(productName.toLowerCase());
    }

    // Method to purchase a quantity of a product
    public boolean purchaseProduct(String productName, int quantity) {
        Product product = productMap.get(productName.toLowerCase());
        if (product != null && product.quantity >= quantity) {
            product.quantity -= quantity;
            System.out.println("Purchase successful: " + quantity + " " + productName + "(s) for $" + (product.price * quantity));
            return true;
        } else {
            System.out.println("Purchase failed. Insufficient quantity or product not found.");
            return false;
        }
    }

    // Method to add a new product to the store
    public void addNewProduct(String productName, double price, int quantity) {
        Product newProduct = new Product(productName, price, quantity);
        insertProduct(newProduct);
        System.out.println("New product added: " + productName);
    }

    // Method to delete a product from the store
    public void deleteProduct(String productName) {
        Product productToDelete = searchProduct(productName);
        if (productToDelete != null) {
            removeProduct(productToDelete);
            System.out.println("Product deleted: " + productName);
        } else {
            System.out.println("Product not found. Deletion failed.");
        }
    }

    // Method to modify the price of a product
    public void modifyProductPrice(String productName, double newPrice) {
        Product productToModify = searchProduct(productName);
        if (productToModify != null) {
            productToModify.price = newPrice;
            System.out.println("Price modified for " + productName + ": $" + newPrice);
        } else {
            System.out.println("Product not found. Modification failed.");
        }
    }

    // Method to modify the quantity of a product
    public void modifyProductQuantity(String productName, int newQuantity) {
        Product productToModify = searchProduct(productName);
        if (productToModify != null) {
            productToModify.quantity = newQuantity;
            System.out.println("Quantity modified for " + productName + ": " + newQuantity);
        } else {
            System.out.println("Product not found. Modification failed.");
        }
    }
}
